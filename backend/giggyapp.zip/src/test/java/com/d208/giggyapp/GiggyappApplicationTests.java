package com.d208.giggyapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GiggyappApplicationTests {

	@Test
	void contextLoads() {
	}

}
