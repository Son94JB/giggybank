package com.d208.giggyapp.domain.board;

public enum Category {
    FOOD, SELFDEV, SHOPPING, TRAFFIC, LEISURE, ETC, FIXED
}
