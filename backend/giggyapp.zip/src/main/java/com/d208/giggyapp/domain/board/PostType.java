package com.d208.giggyapp.domain.board;

public enum PostType {
    FREE, TIP, BOAST
}
